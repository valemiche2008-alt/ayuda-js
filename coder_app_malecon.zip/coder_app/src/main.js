import "./style.css";
import { getElementById } from "./utils/getElementById";

const app = getElementById("app");

const formLogin = getElementById("form_login");

const store =  {
    user: null,
    isLogin: false,

    login(data){
      this.user = data;
      this.isLogin = true;
    },

    saveData(data){
      localStorage.setItem('user', JSON.stringify(data))
    }
}

const dataUser = [
  {
    id: 1,
    name: "Alejandro",
    role: "coder",
    email: "alejandro.villanueva@riwi.io",
    password: "coder123",
  },
  {
    id: 2,
    name: "Abrahan",
    role: "team leader",
    email: "abrahan.villa@riwi.io",
    password: "teamleader123",
  },
  {
    id: 3,
    name: "Camila",
    role: "designer",
    email: "camila.rojas@riwi.io",
    password: "designer123",
  },
  {
    id: 4,
    name: "Sebastian",
    role: "backend developer",
    email: "sebastian.mora@riwi.io",
    password: "backend123",
  },
  {
    id: 5,
    name: "Valentina",
    role: "frontend developer",
    email: "valentina.gomez@riwi.io",
    password: "frontend123",
  },
  {
    id: 6,
    name: "Juan",
    role: "qa tester",
    email: "juan.perez@riwi.io",
    password: "qatester123",
  },
  {
    id: 7,
    name: "Laura",
    role: "project manager",
    email: "laura.castillo@riwi.io",
    password: "manager123",
  },
  {
    id: 8,
    name: "Daniel",
    role: "devops",
    email: "daniel.ramirez@riwi.io",
    password: "devops123",
  },
  {
    id: 9,
    name: "Sofia",
    role: "ux/ui designer",
    email: "sofia.martinez@riwi.io",
    password: "uxui123",
  },
  {
    id: 10,
    name: "Mateo",
    role: "data analyst",
    email: "mateo.lopez@riwi.io",
    password: "data123",
  },
];

formLogin.addEventListener("submit", (e) => {
  e.preventDefault();

  const { email, password } = Object.fromEntries(new FormData(formLogin));

  const getUser = dataUser.filter((user) => user.email === email);
  const getUserFind = dataUser.find(user => user.email === email)

  console.log({getUser, getUserFind});
  
  console.log(getUserFind);
  

  if (email === getUserFind.email && password === getUserFind.password) {
    app.innerHTML = `<p>Bienvenido ${getUser.name}</p>
    <button id="btn_logout" class="ml-2 bg-slate-900 text-white h-10 px-4">logout</button>
    `;
    document.querySelector("#btn_logout").addEventListener("click", () => {

    });
    store.saveData(getUserFind)
    store.login(getUserFind)
    console.log(store);
    
  } else {
    alert("datos erroneos");
  }
});


