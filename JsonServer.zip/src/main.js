import './style.css'

const appContainer = document.getElementById("app")

async function getData() {
  const response = await fetch("http://localhost:3000/coders")
  const data = await response.json()

  return data
}

async function postData(data) {
  fetch("http://localhost:3000/coders", {
    method: 'POST', // Specify the method
    headers: {
      'Content-Type': 'application/json', // Set the correct header
    },
    body: JSON.stringify(data), // Stringify the data object
  })
    .then(response => {
      if (!response.ok) { // Check if the response was successful
        throw new Error('Network response was not ok');
      }
      return response.json(); // Parse the JSON response
    })
    .then(result => {
      console.log('Success:', result);
    })
    .catch(error => {
      console.error('Error:', error);
    });
}

document.getElementById("saveForm").addEventListener("submit", (event) => {
  event.preventDefault()
  const fullname = document.getElementById("fullname").value
  const identification = document.getElementById("identification").value
  const birthdate = document.getElementById("birthdate").value
  const photo = document.getElementById("photo").value
  const description = document.getElementById("description").value

  if (!fullname || !identification || !birthdate || !photo || !description) {
    alert("Todos los campos son requeridos!")
    return
  }

  const data = {
    fullname: fullname,
    identification: identification,
    birthdate: birthdate,
    photo: photo,
    description: description
  }
  postData(data)
})

document.addEventListener("DOMContentLoaded", async () => {
  const dataContainer = document.getElementById("data")
  const data = await getData()
  if (data.length === 0) {
    dataContainer.innerHTML = `<h1 
    class="col-span-1 md:col-span-4 font-bold text-xl">No hay datos disponibles para mostrar</h1>`
  } else {
    data.forEach(element => {
      const { fullname, photo, identification, description, birthdate } = element
      dataContainer.innerHTML += `<div
          class="bg-purple-400/80 flex flex-col items-center justify-center text-gray-200 rounded-md shadow-md shadow-slate-400/50 duration-500 transition-transform hover:scale-[1.03] hover:shadow-xl hover:shadow-slate-600/50 p-3">
          <h1 class="font-bold text-2xl">${fullname}</h1>
          <img class="rounded-md w-100"
            src="${photo}" alt="${fullname}">
          <span class="opacity-80 font-bold">${identification}</span>
          <span class="opacity-70">${birthdate}</span>
          <p class="text-justify">
          ${description}
          </p>
        </div>`
    });
  }
})
